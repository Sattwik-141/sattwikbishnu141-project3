const Note = require("../models/Note");

// =========================
// CREATE NOTE
// =========================

const createNote = async (req, res) => {
    try {
        const { title, content } = req.body;

        if (!title || !content) {
            return res.status(400).json({
                message: "Title and content are required"
            });
        }

        const note = await Note.create({
            title,
            content,
            user: req.user.userId
        });

        res.status(201).json({
            message: "Note created successfully",
            note
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// =========================
// GET ALL NOTES
// =========================

const getNotes = async (req, res) => {
    try {
        const notes = await Note.find({
            user: req.user.userId
        }).sort({
            createdAt: -1
        });

        res.json({
            count: notes.length,
            notes
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// =========================
// GET SINGLE NOTE
// =========================

const getNote = async (req, res) => {
    try {
        const note = await Note.findOne({
            _id: req.params.id,
            user: req.user.userId
        });

        if (!note) {
            return res.status(404).json({
                message: "Note not found"
            });
        }

        res.json(note);

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// =========================
// UPDATE NOTE
// =========================

const updateNote = async (req, res) => {
    try {
        const note = await Note.findOne({
            _id: req.params.id,
            user: req.user.userId
        });

        if (!note) {
            return res.status(404).json({
                message: "Note not found"
            });
        }

        if (req.body.title !== undefined) {
            note.title = req.body.title;
        }

        if (req.body.content !== undefined) {
            note.content = req.body.content;
        }

        await note.save();

        res.json({
            message: "Note updated successfully",
            note
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// =========================
// DELETE NOTE
// =========================

const deleteNote = async (req, res) => {
    try {
        const note = await Note.findOneAndDelete({
            _id: req.params.id,
            user: req.user.userId
        });

        if (!note) {
            return res.status(404).json({
                message: "Note not found"
            });
        }

        res.json({
            message: "Note deleted successfully"
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


module.exports = {
    createNote,
    getNotes,
    getNote,
    updateNote,
    deleteNote
};