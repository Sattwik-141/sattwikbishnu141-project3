const Task = require("../models/Task");

// =========================
// CREATE TASK
// =========================

const createTask = async (req, res) => {
    try {
        const { title, description } = req.body;

        if (!title) {
            return res.status(400).json({
                message: "Title is required"
            });
        }

        const task = await Task.create({
            title,
            description,
            user: req.user.userId
        });

        res.status(201).json({
            message: "Task created successfully",
            task
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// =========================
// GET ALL TASKS
// =========================

const getTasks = async (req, res) => {
    try {
        const tasks = await Task.find({
            user: req.user.userId
        }).sort({
            createdAt: -1
        });

        res.json({
            count: tasks.length,
            tasks
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// =========================
// GET SINGLE TASK
// =========================

const getTask = async (req, res) => {
    try {
        const task = await Task.findOne({
            _id: req.params.id,
            user: req.user.userId
        });

        if (!task) {
            return res.status(404).json({
                message: "Task not found"
            });
        }

        res.json(task);

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// =========================
// UPDATE TASK
// =========================

const updateTask = async (req, res) => {
    try {
        const task = await Task.findOne({
            _id: req.params.id,
            user: req.user.userId
        });

        if (!task) {
            return res.status(404).json({
                message: "Task not found"
            });
        }

        // Update only fields that were provided
        if (req.body.title !== undefined) {
            task.title = req.body.title;
        }

        if (req.body.description !== undefined) {
            task.description = req.body.description;
        }

        if (req.body.completed !== undefined) {
            task.completed = req.body.completed;
        }

        await task.save();

        res.json({
            message: "Task updated successfully",
            task
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// =========================
// DELETE TASK
// =========================

const deleteTask = async (req, res) => {
    try {
        const task = await Task.findOneAndDelete({
            _id: req.params.id,
            user: req.user.userId
        });

        if (!task) {
            return res.status(404).json({
                message: "Task not found"
            });
        }

        res.json({
            message: "Task deleted successfully"
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


module.exports = {
    createTask,
    getTasks,
    getTask,
    updateTask,
    deleteTask
};