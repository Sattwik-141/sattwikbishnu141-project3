# Backend Assignments — Node.js & Express

A collection of backend development projects built using **Node.js, Express.js, and MongoDB**. This repository demonstrates REST API development, JWT-based authentication, password hashing, and CRUD operations.

##  Features

- **User Authentication:** User registration and login using bcrypt password hashing.
- **JWT Authentication:** Secure access to protected API endpoints using JSON Web Tokens.
- **Task Management API:** Create, retrieve, update, and delete tasks.
- **Notes API:** Create, retrieve, update, and delete notes.
- **MongoDB Integration:** Store and manage application data using MongoDB.
- **Environment Variables:** Keep database credentials and authentication secrets outside the source code.
- **RESTful API Design:** Organized routes, controllers, models, and middleware.

## 🛠️ Tech Stack

- **Runtime:** Node.js
- **Framework:** Express.js
- **Database:** MongoDB Atlas
- **ODM:** Mongoose
- **Authentication:** JSON Web Tokens (JWT)
- **Password Hashing:** bcryptjs
- **Environment Configuration:** dotenv
- **API Testing:** Thunder Client
- **Development Tool:** Nodemon

## 📁 Project Structure

```text
backend-assignments/
├── controllers/
│   ├── authController.js
│   ├── taskController.js
│   └── noteController.js
├── middleware/
│   └── authMiddleware.js
├── models/
│   ├── User.js
│   ├── Task.js
│   └── Note.js
├── routes/
│   ├── authRoutes.js
│   ├── taskRoutes.js
│   └── noteRoutes.js
├── screenshots/
├── .env.example
├── .gitignore
├── package.json
├── package-lock.json
└── server.js
```


### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment variables

Create a `.env` file in the project root using `.env.example` as a reference.

```env
PORT=5000
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_random_secret_key
```

Replace the placeholder values with your own configuration. Never commit your real `.env` file or expose your database credentials.

### 3. Start the server

For development:

```bash
npm run dev
```

For normal execution:

```bash
npm start
```

The server runs at:

`http://localhost:5000`

## 🔗 API Endpoints

All endpoints use the base URL `http://localhost:5000`.

### Authentication

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Register a new user |
| POST | `/api/auth/login` | Log in and receive a JWT |

### Tasks API

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/tasks` | Create a task |
| GET | `/api/tasks` | Get the authenticated user's tasks |
| GET | `/api/tasks/:id` | Get a task by ID |
| PUT | `/api/tasks/:id` | Update a task |
| DELETE | `/api/tasks/:id` | Delete a task |

### Notes API

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/notes` | Create a note |
| GET | `/api/notes` | Get the authenticated user's notes |
| GET | `/api/notes/:id` | Get a note by ID |
| PUT | `/api/notes/:id` | Update a note |
| DELETE | `/api/notes/:id` | Delete a note |

## 🔐 Authentication

Protected endpoints require a valid JWT in the request headers:

```http
Authorization: Bearer YOUR_JWT_TOKEN
```

Obtain the token by logging in through the authentication endpoint, then include it in requests to protected routes.

## 🧪 Testing

The APIs were tested using **Thunder Client** in Visual Studio Code.**Postman** can also be used. Requests cover user registration, login, and CRUD operations for tasks and notes.

## 🎯 Learning Objectives

- Building RESTful APIs with Express.js
- Implementing authentication and authorization using JWT
- Hashing passwords securely with bcryptjs
- Designing MongoDB schemas using Mongoose
- Structuring a backend application with MVC-style separation
- Managing environment variables and database connections
- Testing API endpoints using an API client

## 🔮 Future Improvements

- Add request validation and centralized error handling
- Add pagination, filtering, and search
- Add automated API tests
- Add API documentation using Swagger
- Deploy the backend to a cloud platform

## 👨‍💻 Author

**Sattwik Bishnu**



